<?php
$host = "localhost"; //host name
$username = "root"; //username
$password = "softwarepro"; //pass
$db_name = "docdoc"; 
$tbl_name = "log_in";
//Connect to server and select databse
@mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
// username and password sent from form 
$myusername=(isset($_POST['ul_id']) ? $_POST['ul_id'] : ''); 
$mypassword=(isset($_POST['password']) ? $_POST['ul_id'] : '');
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysql_real_escape_string($myusername);
$mypassword = mysql_real_escape_string($mypassword);
$sql="SELECT * FROM $tbl_name WHERE ul_id='$myusername' and password='$mypassword'";
$result=mysql_query($sql);
// Mysql_num_row is counting table row
$count=mysql_num_rows($result);
// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){
// Register $myusername, $mypassword and redirect to file "login_success.php"
session_register("myusername");
session_register("mypassword"); 
header("mainPage.html");
}
else {
        printf("Invalid username or password");
       // header("Location: LogInPage.php"); //Redirect user back to your login form
}
?>