<!DOCTYPE html>
<html>
<link rel="stylesheet" href="assets/css/login.css"/>
<link rel="stylesheet" href="assets/css/bars.css"/>
<head>
<div class="topnav" id="myTopnav">
           <a href="FAQ.php">FAQ</a>           
        </div>
</head>
<title> Validation of Registration </title>
<body>
<div class="container">
	<section id="content">
         <form action="#"> 
            <h1> Verification</h1>
            <p>Please insert 6 digit code for validation</p>
            <input type="number" placeholder="Verification code">
			<div>
            <input type="submit" value="Verify">
			<a href="Validation.php">Re-Send Code</a>
			</div>
        </form>
	</section>
</div>
</body>
</html>
