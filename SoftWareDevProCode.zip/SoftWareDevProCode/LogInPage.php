<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Welcome to Doc Doc </title>
      <link rel="stylesheet" href="assets/css/login.css">
</head>
 <body>
 <div class="container">
	<section id="content">
		<form action="mainPage.php">
		    <ul class="errorMessages"></ul>
			<h1>Login Form</h1>
			<div>
				<input type="email" placeholder="email" pattern="[0-9]{6,9}@(studentmail.ul.ie|ul.ie)" required="" id="emailaddress" />
			</div>
			<div>
				<input type="password" placeholder="Password" required="" id="password" />
			</div>
			<div>
				<input type="submit" value="Log in" />
				<a href="LostPassword.php">Lost your password?</a>
				<a href="RegistrationForm.php">Register</a>
			</div>
		</form><!-- form -->
	</section><!-- content -->
</div><!-- container -->
<script src="js/index2.js"></script>
</body>
</html>
